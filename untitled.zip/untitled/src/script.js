// 1. Smooth Scroll (Lenis)
const lenis = new Lenis();
function raf(time) {
    lenis.raf(time);
    requestAnimationFrame(raf);
}
requestAnimationFrame(raf);

// 2. Loader
window.addEventListener('load', () => {
    const loader = document.getElementById('loader');
    setTimeout(() => { loader.style.opacity = '0'; loader.style.display = 'none'; }, 1000);
});

// 3. Inventory - السلعة مع الصور والأسماء
const items = [
    { name: "SULTAN BLACK", price: "1,500 DH", img: "https://images.unsplash.com/photo-1511499767350-a1590fdb7ca7?w=800" },
    { name: "GOLDEN KOUTOUBIA", price: "2,200 DH", img: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800" },
    { name: "ROYAL MARRAKECH", price: "1,100 DH", img: "https://images.unsplash.com/photo-1473496169904-658ba7c44d8a?w=800" },
    { name: "ATLAS PRO", price: "1,850 DH", img: "https://images.unsplash.com/photo-1577803645773-f96470509666?w=800" }
];

const container = document.getElementById('products');
items.forEach(item => {
    container.innerHTML += `
        <div class="card">
            <div class="card-img-wrap">
                <img src="${item.img}" alt="${item.name}">
                <div class="price-badge">${item.price}</div>
            </div>
            <div class="card-content">
                <h3>${item.name}</h3>
                <button class="order-btn" onclick="whatsapp('${item.name}')">
                    طلب عبر الواتساب
                </button>
            </div>
        </div>
    `;
});

function whatsapp(product) {
    const phone = "212600000000"; // بدلها بنمرة لالة أسماء
    const msg = `مرحباً KOUTOUBIA OPTIC، أرغب في طلب: ${product}`;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`);
}